from xml.dom import UserDataHandler

def user_details():
    """
    Prompt user input
    """


def create_user_name(first_name, last_name, cohort, final_campus):
    """
    Create and return a valid username
    """


def user_campus(campus):
    """
    Return valid campus abbreviations
    """


if __name__ == '__main__':
    user_details()
    